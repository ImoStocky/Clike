/*! \file
 *
 *
 */

#include "ads.h"
#include "types.h"

// Table of synt. rules source nonterminal remains hidden for now, not finished
int LL_rules[][14]={
	{ PROG_N, FUNC, NTE },
	{ PROG_N, FUNC, NTE },
	{ NTE },
	{ FUNC_REST, BRACER_OP, FD_PARAM, BRACEL_OP, IDENT_TK, TYPE, NTE },
	{ NTE },
	{ FD_PARAM_N, IDENT_TK, TYPE, COM_OP, NTE },
	{ NTE },
	{ SEMI_OP, NTE },
	{ BLOCKR_OP, STAT_BLOCK, BLOCKL_OP, NTE },
	{ STAT_N, STAT, NTE },
	{ EPS, NTE },
	{ EPS, NTE },
	{ VAR_DEF, IDENT_TK, TYPE, NTE },
	{ IF_BODY, BRACER_OP, EXPR, BRACEL_OP, IF_KW, NTE },
	{ BLOCKR_OP, STAT_BLOCK, BLOCKL_OP, BRACER_OP, EXPR, SEMI_OP, 
		EXPR_OR_EPS, SEMI_OP, EXPR, ASSIGN_OP, IDENT_TK, TYPE, BRACEL_OP, FOR_KW, NTE },
	{ BLOCKR_OP, STAT_BLOCK, BLOCKL_OP, BRACER_OP, EXPR, BRACEL_OP, WHILE_KW, NTE },
	{ SEMI_OP, BRACER_OP, EXPR, BRACEL_OP, WHILE_KW, BLOCKR_OP, STAT_BLOCK, BLOCKL_OP, DO_KW, NTE},
	{ EXPR, RETURN_KW, NTE},
	{ EXPR, ASSIGN_OP, IDENT_TK, NTE},
	{ ID_LIST, IDENT_TK, DBL_GRE_OP, CIN_KW, NTE},
	{ COUT_EXPR_N, EXPR, DBL_LESS_OP, COUT_KW, NTE},
	{ COUT_EXPR_N, EXPR, DBL_LESS_OP, NTE},
	{ SEMI_OP, NTE },
	{ ID_LIST, IDENT_TK, DBL_GRE_OP, NTE},
	{ SEMI_OP, NTE },
	{ ELSE_OR_NOT, EXPR, NTE},
	{ ELSE_OR_NOT, BLOCKR_OP, STAT_BLOCK, BLOCKL_OP, NTE},
	{ ELSE_BODY, ELSE_KW, NTE},
	{ NTE },
	{ EXPR, NTE },
	{ BLOCKR_OP, STAT_BLOCK, BLOCKL_OP, NTE},
	{ SEMI_OP, NTE },
	{ EXPR, ASSIGN_OP, NTE},
};

// Predict LL derivarion table
int LL_predict[][20]={
	{ /*to fill*/ },

	}
};

enum pda_set_e{
	NONTERM = 0;
	TERM = 1;
	END_KW;
}

int syntal_pred_parse(symb_table_t* st, stack_t* z){

	si_push(z, END_KW);
	si_push(z, PROG); 

	int state = 0;
	int symbol;
	token_t tok;
	int* lemma;

	do{
		scanner_generateToken(&tok);
		si_top(z, &symbol);

		int s_set = (symbol > NTS ? NONTERM : TERM);
		s_set = (symbol == END_KW ? END_KW : s_set);

				switch(s_set)
				{
				case END_KW:	
					if( symbol == tok.type ) state = 1;
					else state = -1;
				break;

				case TERM:
				if( symbol == tok.type ){
					si_pop(z);
					scanner_generateToken(&tok);
				} else state = -1;
				break;
				
				case NONTERM:
					if( (rule = LL_predict(symbol, tok.type, &lemma)) != NULL ){
						si_pop(z);
						si_push_rule(z, lemma);
					}else state = -1;

				break;

				}			
				
	}while(state == 0);

}

int syntal_prec_parse(/**/stack_t* z){
	
	token_t tok;
	int state = 0;
	int symbol;

	scanner_generateToken(&tok);

	si_push(st, END_KW);
	si_topTerm(st, &symbol, selector);
	
	do{
		switch( next_prec ){
			case EQ_PREC: 
				si_push(st, tok.type);
				scanner_generateToken(&tok);
				break;
			case LT_PREC:
				si_pushAfter(st, LT_PREC, selector);
				si_push(st, tok.type);
				scanner_generateToken(&tok);
				break;	
			case GR_PREC:
				if( 0 == si_topSet(st, lemma, selector) && ((rule = PA_pick(lemma))!= NULL)){
					si_tpopSet(st, lemma, selector);
					si_pushSet(st, rule, ruleLen);
				} else state = -1;
				break;
			case NO_PREC:
				state = -1;
		}

			
	} while( symbol == END_KW && tok.type == END_KW );
}
